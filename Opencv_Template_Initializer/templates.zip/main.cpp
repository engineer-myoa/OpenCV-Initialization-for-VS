/*
 Initializer developed by [Kongju National University 201301966 Shin Woo-Jin]
 If you have any questions, please send me an email.
 myoatm@gmail.com

 Version 1.0
 
*/

#include <iostream>
#include <opencv2\opencv.hpp>

using namespace std;
using namespace cv;

int main() {

	Mat src = imread("lena.png", IMREAD_GRAYSCALE);
	
	return 0;
}